<?php
/**
 * Plugin Name: Agency OS Approved Publisher
 * Description: Applies explicitly approved website changes and verifies their saved values.
 * Version: 0.5.6
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Update URI: https://github.com/Bholmstock/agency-os-publisher-releases
 */
if (!defined('ABSPATH')) exit;
// 0.5.0 — a WordPress site is where content, permissions and URL conflicts
// are truly known, so publishing preflight lives here too: it runs the same
// checks /apply would, without writing anything, and names which one failed
// instead of one generic refusal. AOS_MANIFEST_URL and the Update URI header
// above point at the public release-only repository
// github.com/Bholmstock/agency-os-publisher-releases; override
// AOS_MANIFEST_URL in wp-config.php only if that repository moves.
if(!defined('AOS_MANIFEST_URL'))define('AOS_MANIFEST_URL','https://raw.githubusercontent.com/Bholmstock/agency-os-publisher-releases/main/manifest.json');
define('AOS_PLUGIN_VERSION','0.5.6');
// 0.5.2 — category intelligence is a new, truthfully-advertised capability
// (see /capabilities and /categories below). It is genuinely additive, not
// merely additive-by-intent, because it is gated by an explicit request-side
// marker rather than by this plugin's own version: a new_post change is only
// held to the category contract when it carries
// 'categoryContractVersion'=>AOS_CATEGORY_CONTRACT_VERSION (see
// aos_category_contract_state() below). A request that OMITS the marker
// entirely — a genuine 0.5.1-era Agency OS, or any client that has not
// reviewed a category selection — publishes exactly as 0.5.1 always did: no
// category checks, no category assignment, WordPress's own default category
// applies. Only a request that both declares the marker AND was prepared by
// an Agency OS that first confirmed this site advertises category support
// (see /capabilities) is required to carry a valid, reviewed primary
// category. A request that carries the marker with a value this plugin does
// NOT understand (anything other than the exact integer
// AOS_CATEGORY_CONTRACT_VERSION) is a THIRD, distinct case: it is never
// treated as "absent" and never allowed to bypass category enforcement —
// see aos_category_contract_state() — it is refused outright with an
// explicit category_contract check, before any post is created. This is
// also why the protocol version below can safely stay unchanged: nothing
// about the existing wire contract is different for a caller that never
// opts into the newer one, in either version direction — a 0.5.2 Agency OS
// talking to a 0.5.1 site degrades the same way (it never learns this site
// supports categories, so it never sends the marker either).
define('AOS_PROTOCOL_VERSION',3);
// 0.5.2 — the category contract's own version, independent of the plugin
// version. See aos_category_contract_state() for how a new_post change's
// marker (absent / valid / invalid) is decided against this constant.
define('AOS_CATEGORY_CONTRACT_VERSION',1);
// 0.5.3 — image sub-size generation is intentionally deferred until after
// the approved article has been saved, published, and verified. Some managed
// hosts terminate long REST requests while WordPress/Divi creates every
// registered thumbnail size for multiple large PNGs. The original approved
// files are still uploaded and hash-verified synchronously; only derivative
// thumbnails move to a one-shot WP-Cron job. The article therefore never
// depends on background work, while the Media Library can fill in its normal
// responsive sizes shortly after publication without holding /apply open.
function aos_generate_attachment_metadata_deferred($attachmentId){
 $attachmentId=(int)$attachmentId;$file=$attachmentId?get_attached_file($attachmentId):false;
 if(!$file||!file_exists($file))return;
 require_once ABSPATH.'wp-admin/includes/image.php';
 $metadata=wp_generate_attachment_metadata($attachmentId,$file);
 if(!is_wp_error($metadata)&&is_array($metadata))wp_update_attachment_metadata($attachmentId,$metadata);
}
add_action('aos_generate_attachment_metadata','aos_generate_attachment_metadata_deferred',10,1);
function aos_schedule_attachment_metadata($media){
 foreach((array)$media as $m){$attachmentId=(int)($m['attachmentId']??0);if(!$attachmentId)continue;
  $args=array($attachmentId);
  if(!wp_next_scheduled('aos_generate_attachment_metadata',$args))wp_schedule_single_event(time()+5,'aos_generate_attachment_metadata',$args);
 }
}
function aos_local_url($url){return strtolower(wp_parse_url($url,PHP_URL_HOST))===strtolower(wp_parse_url(home_url(),PHP_URL_HOST))&&wp_parse_url($url,PHP_URL_SCHEME)==='https';}
function aos_state($id){$p=get_post($id);return array('content'=>$p->post_content,'title'=>get_post_meta($id,'rank_math_title',true),'description'=>get_post_meta($id,'rank_math_description',true),'schema'=>get_post_meta($id,'_aos_schema',true),'featured'=>(int)get_post_thumbnail_id($id),'author'=>(int)$p->post_author,'commentStatus'=>(string)$p->comment_status,'pingStatus'=>(string)$p->ping_status,'layout'=>aos_layout_value($id),'focusKeyword'=>(string)get_post_meta($id,'rank_math_focus_keyword',true));}
// 0.3.0 — how this site can present an article without a sidebar. Divi keeps
// the choice in post meta; other themes may offer a post template whose name
// says full width or no sidebar. When neither exists the publisher says so
// rather than claiming a layout it cannot set.
function aos_layout_mechanism(){
 $theme=wp_get_theme();$names=array_map('strtolower',array_filter(array($theme->get('Name'),$theme->get('Template'),get_template(),get_stylesheet())));
 if(defined('ET_BUILDER_VERSION')||function_exists('et_setup_theme')||in_array('divi',$names,true))return array('mechanism'=>'divi','value'=>'et_full_width_page','label'=>'Divi page layout: full width');
 $templates=$theme->get_page_templates(null,'post');
 if(is_array($templates))foreach($templates as $file=>$name){if(preg_match('/full[-_ ]?width|no[-_ ]?sidebar|sidebar[-_ ]?less/i',$name.' '.$file))return array('mechanism'=>'template','value'=>$file,'label'=>'Post template: '.$name);}
 return array('mechanism'=>null,'value'=>'','label'=>'');
}
function aos_layout_value($id){$m=aos_layout_mechanism();if($m['mechanism']==='divi')return (string)get_post_meta($id,'_et_pb_page_layout',true);if($m['mechanism']==='template')return (string)get_page_template_slug($id);return '';}
// Eligible authors: users who can write posts here. Names and roles only.
function aos_authors(){
 $users=function_exists('wp_roles')?get_users(array('capability'=>'edit_posts','number'=>100,'orderby'=>'display_name','order'=>'ASC')):array();
 if(!count($users))$users=get_users(array('role__in'=>array('administrator','editor','author'),'number'=>100,'orderby'=>'display_name','order'=>'ASC'));
 $roles=wp_roles()->role_names;$out=array();
 foreach($users as $u){if(!user_can($u->ID,'edit_posts'))continue;$role=isset($u->roles[0])&&isset($roles[$u->roles[0]])?translate_user_role($roles[$u->roles[0]]):'';$out[]=array('id'=>(int)$u->ID,'name'=>(string)$u->display_name,'role'=>$role);}
 return array('default'=>get_current_user_id(),'canAssign'=>current_user_can('edit_others_posts'),'users'=>$out);
}
// 0.5.2 — every category this site has, read-only. Stable ids, names, slugs,
// parents and counts, plus the site's own default (usually "Uncategorized")
// so Agency OS never recommends the unchanged fallback as if it were a real
// choice. Category creation needs manage_categories; this function only ever
// reads.
function aos_categories(){
 $terms=get_categories(array('hide_empty'=>false,'number'=>300));
 $out=array();
 foreach($terms as $t)$out[]=array('id'=>(int)$t->term_id,'name'=>(string)$t->name,'slug'=>(string)$t->slug,'parent'=>(int)$t->parent,'count'=>(int)$t->count);
 return array('default'=>(int)get_option('default_category'),'canCreate'=>current_user_can('manage_categories'),'categories'=>$out);
}
// 0.5.2 — the same checks aos_new_post_checks() folds in, split out for
// clarity: a primary category is required, a resolvable id or an explicitly
// approved new name/slug with no conflict; a secondary category, if any,
// follows the same rule and must differ from the primary; creating any new
// category needs manage_categories. Nothing here writes to the site.
function aos_category_checks($cat){
 $checks=array();
 $categories=aos_categories();$slugs=array();$ids=array();
 foreach($categories['categories'] as $t){$slugs[]=strtolower($t['slug']);$ids[(int)$t['id']]=true;}
 $resolve=function($sel)use($ids,$slugs){
  if(!is_array($sel))return array(false,'');
  if(($sel['source']??'')==='existing')return array(isset($ids[(int)($sel['id']??0)]),'');
  if(($sel['source']??'')==='new'){
   $name=trim((string)($sel['name']??''));$slug=strtolower((string)($sel['slug']??''));$approved=!empty($sel['approved']);
   if($name===''||!preg_match('/^[-a-z0-9]+$/',$slug))return array(false,'');
   if(in_array($slug,$slugs,true))return array(false,'A category with this slug already exists. Choose the existing category instead.');
   if(!$approved)return array(false,'Approve creating this category before publishing.');
   return array(true,'');
  }
  return array(false,'');
 };
 $primary=is_array($cat)?($cat['primary']??null):null;$secondary=is_array($cat)?($cat['secondary']??null):null;
 list($primaryOk,$primaryMsg)=$resolve($primary);
 $checks[]=array('code'=>'category_primary','ok'=>is_array($primary)&&$primaryOk,'message'=>is_array($primary)?($primaryOk?'':($primaryMsg?:'Choose a valid primary category.')):'A primary category is required.');
 if($secondary!==null){list($secondaryOk,$secondaryMsg)=$resolve($secondary);$checks[]=array('code'=>'category_secondary','ok'=>$secondaryOk,'message'=>$secondaryOk?'':($secondaryMsg?:'Choose a valid additional category.'));}
 $creating=(is_array($primary)&&($primary['source']??'')==='new')||(is_array($secondary)&&($secondary['source']??'')==='new');
 $permission=!$creating||current_user_can('manage_categories');
 $checks[]=array('code'=>'category_permission','ok'=>$permission,'message'=>$permission?'':'Creating a new category requires category-management permission on this site.');
 $duplicateExisting=is_array($primary)&&is_array($secondary)&&($primary['source']??'')==='existing'&&($secondary['source']??'')==='existing'&&(int)($primary['id']??0)===(int)($secondary['id']??-1);
 $duplicateNew=is_array($primary)&&is_array($secondary)&&($primary['source']??'')==='new'&&($secondary['source']??'')==='new'&&strtolower((string)($primary['slug']??''))===strtolower((string)($secondary['slug']??'\0'));
 $checks[]=array('code'=>'category_duplicate','ok'=>!($duplicateExisting||$duplicateNew),'message'=>($duplicateExisting||$duplicateNew)?'The primary and additional category must be different.':'');
 return $checks;
}
function aos_snapshot($url){
 if(!aos_local_url($url))return new WP_Error('site','Choose a page on this website',array('status'=>400));$id=url_to_postid($url);
 if(!$id)return array('url'=>$url,'exists'=>false,'content'=>'','title'=>'','description'=>'','beforeHash'=>hash('sha256','absent:'.$url));
 if(!current_user_can('edit_post',$id))return new WP_Error('access','This page cannot be edited',array('status'=>403));$s=aos_state($id);return array_merge($s,array('url'=>get_permalink($id),'exists'=>true,'postId'=>$id,'pageTitle'=>get_the_title($id),'beforeHash'=>hash('sha256',wp_json_encode($s))));
}
// 0.5.2 — the categories a job actually wrote, read back from the post
// itself (never from what apply merely believes it did), each named with
// whether it is still assigned right now, plus the Rank Math primary-category
// meta when Rank Math is present. Read-only.
function aos_category_receipt($id,$catJob){
 if(!is_array($catJob))return null;
 $assignedIds=wp_get_post_categories($id);
 // 0.5.2.2 — wp_get_post_categories() can return a WP_Error or some other
 // non-array value (a site-level failure reading terms back). Never pass
 // either into in_array() below: treat it as "nothing confirmed assigned"
 // so this read-only receipt reports honestly unverified instead of fatally
 // erroring.
 if(is_wp_error($assignedIds)||!is_array($assignedIds))$assignedIds=array();
 $describe=function($tid)use($assignedIds){
  if(!$tid)return null;$term=get_term($tid,'category');
  return array('id'=>(int)$tid,'name'=>($term&&!is_wp_error($term))?(string)$term->name:'','verified'=>in_array((int)$tid,$assignedIds,true));
 };
 $primary=$describe($catJob['primaryId']??0);
 $secondary=($catJob['secondaryId']??null)?$describe($catJob['secondaryId']):null;
 $rankMathPrimary=defined('RANK_MATH_VERSION')?(int)get_post_meta($id,'rank_math_primary_category',true):0;
 return array('primary'=>$primary,'secondary'=>$secondary,'created'=>$catJob['created']??array(),'rankMath'=>array('supported'=>defined('RANK_MATH_VERSION'),'verified'=>defined('RANK_MATH_VERSION')&&$rankMathPrimary===(int)($catJob['primaryId']??0)));
}
function aos_categories_verified($id,$catJob){
 $info=aos_category_receipt($id,$catJob);
 if(!$info||!$info['primary'])return false;
 return $info['primary']['verified']&&($info['secondary']===null||$info['secondary']['verified']);
}
function aos_receipt($j){
 $id=$j['postId'];if(!$id){$ids=get_posts(array('post_type'=>array('post','page'),'post_status'=>'any','meta_key'=>'_aos_job','meta_value'=>$j['jobId'],'fields'=>'ids'));$id=count($ids)===1?$ids[0]:0;}
 if(!$id)return array('jobId'=>$j['jobId'],'proposalHash'=>$j['proposalHash'],'verified'=>false,'url'=>$j['url'],'postId'=>0);
 if(!current_user_can('edit_post',$id))return new WP_Error('access','Not permitted',array('status'=>403));
 $s=aos_state($id);$ok=is_array($j['expected'])&&count($j['expected'])>0;foreach(($j['expected']??array()) as $k=>$v)$ok=$ok&&array_key_exists($k,$s)&&$s[$k]===$v;foreach(($j['media']??array()) as $m){$file=function_exists('wp_get_original_image_path')?wp_get_original_image_path($m['attachmentId']):get_attached_file($m['attachmentId']);$ok=$ok&&$file&&file_exists($file)&&hash_file('sha256',$file)===$m['sha256']&&get_post_meta($m['attachmentId'],'_wp_attachment_image_alt',true)===$m['alt'];}if(isset($j['newTitle']))$ok=$ok&&get_post($id)->post_title===$j['newTitle']&&get_post_status($id)==='publish';
 // 0.5.2 — an approved new post that named categories is verified only once
 // WordPress confirms them actually assigned, exactly like every other
 // expected field above; Rank Math's own primary-category meta is reported
 // honestly but never required for $ok, since not every site runs Rank Math.
 $categories=isset($j['categories'])?aos_category_receipt($id,$j['categories']):null;
 if($categories!==null)$ok=$ok&&aos_categories_verified($id,$j['categories']);
 // 0.3.0 — what the website can vouch for, each named, and a layout that
 // could not be set said so rather than folded into "verified".
 $content=get_post($id)->post_content;$supporting=array();foreach(($j['media']??array()) as $m){if(($m['role']??'')==='featured')continue;$src=wp_get_attachment_url($m['attachmentId']);$supporting[]=array('attachmentId'=>(int)$m['attachmentId'],'inserted'=>$src&&strpos($content,$src)!==false);}
 $mech=$j['layoutMechanism']??null;$layout=array('requested'=>$j['layoutRequested']??'','mechanism'=>$mech,'value'=>$s['layout'],'verified'=>($j['layoutRequested']??'')!=='full_width'?null:($mech?$s['layout']===$j['expected']['layout']:false),'note'=>($j['layoutRequested']??'')==='full_width'&&!$mech?'Full-width layout could not be verified for this site.':'');
 return array('jobId'=>$j['jobId'],'proposalHash'=>$j['proposalHash'],'url'=>get_permalink($id),'verified'=>$ok,'postId'=>(int)$id,'postType'=>get_post_type($id),'verifiedAt'=>gmdate('c'),'author'=>(int)$s['author'],'authorName'=>(string)get_the_author_meta('display_name',$s['author']),'commentStatus'=>$s['commentStatus'],'pingStatus'=>$s['pingStatus'],'featuredMediaId'=>(int)$s['featured'],'supportingImages'=>$supporting,'seo'=>array('title'=>$s['title']!=='','description'=>$s['description']!=='','focusKeyword'=>$s['focusKeyword']!=='','rankMath'=>defined('RANK_MATH_VERSION')),'layout'=>$layout,'categories'=>$categories);
}
// 0.5.2.3 — a job whose $rollback could not fully remove its post (see
// aos_apply()'s $rollback closure) is never allowed to fall through to a
// normal aos_receipt() replay, which could misreport a still-public,
// unresolved article as an ordinary (even verified) receipt. This is the
// dedicated, honest status for exactly that case, called every time such a
// job is looked up again — it re-reads the post's ACTUAL current status
// fresh each time (never the stale status recorded when cleanup failed),
// since an operator may have intervened manually since. A WP_Error is
// returned either way, never a receipt shape, so this can never be mistaken
// for a completed job.
function aos_cleanup_status($j){
 $postId=(int)($j['cleanup']['postId']??0);
 $status=$postId?get_post_status($postId):false;
 if(!$postId||$status===false)return new WP_Error('cleanup_resolved','A previous attempt for this job required manual cleanup and the post no longer exists on this site. If this was resolved manually, submit a new publishing request rather than retrying this exact job.',array('status'=>409,'jobId'=>$j['jobId']));
 if($status==='publish')return new WP_Error('cleanup_required_critical','A previous attempt for this job left an article publicly visible that could not be safely removed. It may still be public and requires immediate manual action: review and unpublish or delete post ID '.$postId.' on this site.',array('status'=>500,'jobId'=>$j['jobId'],'postId'=>$postId));
 return new WP_Error('cleanup_required','A previous attempt for this job left a draft that could not be fully removed automatically. It has been verified non-public (post ID '.$postId.'), but needs manual review before retrying this job.',array('status'=>409,'jobId'=>$j['jobId'],'postId'=>$postId));
}
// WordPress rewrites entities as it filters (wp_kses_normalize_entities pads
// &#39; to &#039;), so safety is judged against that normalised form, and the
// normalised form is what gets published. Any tag or attribute wp_kses_post
// would remove still fails: only entity spelling is forgiven.
function aos_normalized_html($html){return is_string($html)?wp_kses_normalize_entities($html):'';}
function aos_safe_html($html){if(!is_string($html)||trim($html)===''||strlen($html)>400000)return false;$n=aos_normalized_html($html);return wp_kses_post($n)===$n;}
// 0.5.0 — every reason a new publication cannot proceed, named and checked
// independently rather than folded into one message. /apply uses the first
// failure to refuse the write; /preflight reports all of them so a person can
// fix everything at once, before Agency OS offers final approval.
function aos_new_post_checks($c,$id,$new){
 $checks=array();
 $conflict=$id||$new;
 $checks[]=array('code'=>'url_conflict','ok'=>!$conflict,'message'=>$id?'A page or post already exists at this address.':($new?'Only one new publication can be proposed at a time.':''));
 $postType=$c['postType']??'';$validType=in_array($postType,array('post','page'),true);
 $checks[]=array('code'=>'post_type','ok'=>$validType,'message'=>$validType?'':'Choose a post type of post or page.');
 $permission=$validType&&current_user_can($postType==='page'?'publish_pages':'publish_posts');
 $checks[]=array('code'=>'permission','ok'=>$permission,'message'=>$permission?'':'This WordPress user cannot publish '.($postType==='page'?'pages':'posts').' on this site.');
 $title=trim($c['title']??'')!=='';
 $checks[]=array('code'=>'title','ok'=>$title,'message'=>$title?'':'A title is required.');
 $slugOk=preg_match('/^[-a-z0-9]+$/',$c['slug']??'')===1;
 $checks[]=array('code'=>'slug','ok'=>$slugOk,'message'=>$slugOk?'':'The slug may only contain lowercase letters, numbers and hyphens.');
 $contentOk=is_string($c['html']??'')&&trim($c['html']??'')!=='';
 $checks[]=array('code'=>'content','ok'=>$contentOk,'message'=>$contentOk?'':'The article content is empty.');
 $safe=!$contentOk||aos_safe_html($c['html']);
 $checks[]=array('code'=>'html_safety','ok'=>$safe,'message'=>$safe?'':'The content contains markup WordPress will not allow.');
 // 0.5.2 — a category is part of what makes a new publication complete, the
 // same standing as its title, slug and content above: named, checked
 // independently, and never quietly defaulted to Uncategorized. But only for
 // a request that opted into the category contract: a legacy request that
 // never declares 'categoryContractVersion' (a genuine 0.5.1 Agency OS, or
 // any client that has not reviewed a category selection with this site)
 // must publish exactly as 0.5.1 always did, not be refused for a category
 // it was never asked to provide.
 $contractState=aos_category_contract_state($c);
 if($contractState==='invalid'){
  $checks[]=array('code'=>'category_contract','ok'=>false,'message'=>'This category selection uses a category-contract version this site does not support. Update Agency OS and try again.');
 }elseif($contractState==='valid'){
  foreach(aos_category_checks($c['categories']??null) as $cc)$checks[]=$cc;
 }
 return $checks;
}
// 0.5.2.2 — whether a new_post change carries a category-contract marker,
// and if so, whether it is one this plugin actually understands. Exactly
// three outcomes, never blurred together:
//  'none'    — no 'categoryContractVersion' key at all: a genuine 0.5.1-era
//              request, or any client that never reviewed a category
//              selection. Publishes exactly as 0.5.1 always did.
//  'valid'   — the key is present and is exactly the integer
//              AOS_CATEGORY_CONTRACT_VERSION. Category validation and
//              assignment apply in full.
//  'invalid' — the key is present with any other value: 0, a negative
//              number, a future version this plugin does not know how to
//              enforce, or a non-integer such as a numeric string. This is
//              never treated the same as 'none' and never allowed to bypass
//              category enforcement — aos_new_post_checks() refuses it
//              outright via the category_contract check, before any post is
//              created.
function aos_category_contract_state($c){
 if(!is_array($c)||!array_key_exists('categoryContractVersion',$c))return 'none';
 $v=$c['categoryContractVersion'];
 return (is_int($v)&&$v===AOS_CATEGORY_CONTRACT_VERSION)?'valid':'invalid';
}
function aos_category_contract($c){return aos_category_contract_state($c)==='valid';}
function aos_first_failure($checks){foreach($checks as $c)if(!$c['ok'])return $c;return null;}
// 0.5.1 — the exact characters an entity spells out, everywhere a string can
// carry one, including inside an attribute value. Two markup strings that
// decode to the same text differ only in HOW they spell the same characters
// (&#039; vs &apos; vs a literal '), never in what the page actually says or
// which attributes it carries — decoding is a stronger and simpler proof of
// that than re-running WordPress's own whole-document entity normaliser and
// hoping it happens to produce a byte-identical string.
function aos_html_decoded($html){return is_string($html)?html_entity_decode($html,ENT_QUOTES|ENT_HTML5,'UTF-8'):'';}
// 0.5.0.1 — what kind of difference WordPress's own save-time sanitisation
// makes, named so a person can tell entity spelling (harmless) apart from
// WordPress refusing markup or an attribute this site does not allow. A
// heuristic on tag names and a tag-only skeleton, not a full HTML diff —
// good enough to point at the right explanation, never to silently decide.
function aos_classify_html_change($original,$approved){
 if($approved===$original)return null;
 // 0.5.1 — the Q3 regression: WordPress re-spelled an apostrophe already
 // inside the supporting image's alt attribute (&#039; -> &apos;) and this
 // used to fall all the way through to "changed_attributes" because the old
 // check only ever compared the NORMALISED WHOLE STRING for exact equality,
 // which two different entity spellings will never satisfy. Decoding both
 // sides first proves the characters — attribute values included — are
 // identical, which is the only thing "no markup or attribute value
 // actually changed" needs to mean.
 if(aos_html_decoded($approved)===aos_html_decoded($original))return array('type'=>'entity_normalization','message'=>'WordPress represents the same characters with a different HTML entity spelling (for example a straight apostrophe as &#039; vs &apos;), including inside an attribute value. No markup or attribute value actually changed.');
 $normalizedOriginal=aos_normalized_html($original);
 $tagsIn=function($html){preg_match_all('/<([a-z][a-z0-9]*)\b[^>]*>/i',(string)$html,$m);return $m[1];};
 $before=$tagsIn($normalizedOriginal);$after=$tagsIn($approved);
 sort($before);sort($after);
 if($before!==$after)return array('type'=>'removed_markup','message'=>'WordPress removes tags this site does not allow in post content (for example script, iframe or object). Review the exact approved content below.');
 $skeleton=function($html){return preg_replace('/<([a-z][a-z0-9]*)\b[^>]*>/i','<$1>',(string)$html);};
 if($skeleton($normalizedOriginal)===$skeleton($approved))return array('type'=>'changed_attributes','message'=>'WordPress removes or changes attributes this site does not allow (for example an inline style or an unrecognised attribute) — not merely their entity spelling. Review the exact approved content below.');
 return array('type'=>'other','message'=>'WordPress would save this content differently. Review the exact approved content below.');
}
// 0.5.0 — a non-mutating dry run of the same new-publication checks /apply
// enforces, plus the two /apply cannot judge in advance: whether normalising
// this HTML the way WordPress will changes it, and whether the approved
// images are still exactly what was approved. Nothing here writes to the
// site; it only reads. requiredProtocol lets Agency OS refuse to proceed
// when this site's plugin is older than the package needs.
function aos_preflight($r){
 $in=$r->get_json_params();
 $c=null;foreach(($in['changes']??array()) as $x){if(($x['kind']??'')==='new_post'){$c=$x;break;}}
 if(!$c)return new WP_Error('unsupported','Preflight validates a new publication (new_post) proposal',array('status'=>400));
 $url=$in['url']??'';$s=aos_snapshot($url);if(is_wp_error($s))return $s;
 $id=$s['postId']??0;
 $checks=aos_new_post_checks($c,$id,null);
 $required=(int)($in['requiredProtocol']??0);
 $protocolOk=!$required||AOS_PROTOCOL_VERSION>=$required;
 $checks[]=array('code'=>'protocol','ok'=>$protocolOk,'message'=>$protocolOk?'':'This site runs Agency OS Publisher protocol '.AOS_PROTOCOL_VERSION.'; this package needs protocol '.$required.' or later. Update the plugin.');
 $media=$in['media']??array();$mediaOk=true;$mediaMessage='';
 if(!is_array($media)||count($media)>10){$mediaOk=false;$mediaMessage='Too many images.';}
 elseif(count($media)&&!current_user_can('upload_files')){$mediaOk=false;$mediaMessage='Image upload permission is required.';}
 else foreach($media as $m){$bytes=base64_decode($m['base64']??'',true);$size=$bytes?getimagesizefromstring($bytes):false;if(!$bytes||strlen($bytes)>12000000||!$size||!in_array($size['mime'],array('image/png','image/jpeg','image/webp'),true)||$size['mime']!==($m['mimeType']??'')||hash('sha256',$bytes)!==($m['sha256']??'')){$mediaOk=false;$mediaMessage='An approved image is invalid or inaccessible.';break;}}
 $checks[]=array('code'=>'media','ok'=>$mediaOk,'message'=>$mediaMessage);
 // 0.5.0.1 — the exact content WordPress would accept: the same
 // normalisation and wp_kses_post() sanitisation aos_safe_html() judges
 // against, computed here so preflight can show it rather than only refuse.
 $sanitized=null;$htmlChange=null;
 if(is_string($c['html']??'')&&trim($c['html'])!==''){$approved=wp_kses_post(aos_normalized_html($c['html']));if($approved!==$c['html']){$sanitized=$approved;$htmlChange=aos_classify_html_change($c['html'],$approved);}}
 $checks[]=array('code'=>'html_normalized','ok'=>$sanitized===null,'message'=>$sanitized===null?'':'WordPress will save this content differently ('.($htmlChange['type']??'other').'). Review the exact WordPress-approved HTML, adopt it, then check with WordPress again before publishing.');
 $ok=aos_first_failure($checks)===null;
 return array('ok'=>$ok,'checks'=>$checks,'postType'=>(string)($c['postType']??''),'slug'=>(string)($c['slug']??''),'title'=>(string)($c['title']??''),'sanitizedHtml'=>$sanitized,'htmlChange'=>$htmlChange,'protocol'=>AOS_PROTOCOL_VERSION,'version'=>AOS_PLUGIN_VERSION,'preflightedAt'=>gmdate('c'));
}
function aos_apply($r){
 $in=$r->get_json_params();if(!preg_match('/^[a-f0-9-]{36}$/',$in['jobId']??'')||!preg_match('/^[a-f0-9]{64}$/',$in['proposalHash']??''))return new WP_Error('invalid','Invalid approval identifier',array('status'=>400));
 $key='aos_job_'.$in['jobId'];$old=get_option($key);if($old){if($old['proposalHash']!==$in['proposalHash'])return new WP_Error('conflict','Approval identifier already used',array('status'=>409));if(isset($old['cleanup']))return aos_cleanup_status($old);return aos_receipt($old);}
 $url=$in['url']??'';$s=aos_snapshot($url);if(is_wp_error($s))return $s;
 // Optional metadata automation contract. Restoration can only replay the
 // original job's saved values, including an empty override (site default).
 $automatic=array_key_exists('metadataAutomationVersion',$in);$restore=isset($in['restoreOf']);$metadataFields=array();
 if($restore&&!$automatic)return new WP_Error('invalid','Restoration requires the metadata automation contract',array('status'=>400));
 if($automatic){
  $changes=$in['changes']??array();
  if($in['metadataAutomationVersion']!==1||!is_array($changes)||count($changes)!==1||!is_array($changes[0])||($changes[0]['kind']??'')!=='metadata'||!is_array($in['media']??array())||count($in['media']??array())||isset($in['publishing']))return new WP_Error('unsupported','Automatic publishing is limited to search titles and descriptions',array('status'=>409));
  foreach($changes[0] as $f=>$value)if(!in_array($f,array('kind','title','description','reason'),true))return new WP_Error('unsupported','Unsupported automatic metadata field',array('status'=>409));
  foreach(array('title','description') as $f)if(array_key_exists($f,$changes[0]))$metadataFields[]=$f;
  if(!count($metadataFields))return new WP_Error('invalid','No metadata fields selected',array('status'=>400));
  if($restore){
   if(!is_string($in['restoreOf'])||!preg_match('/^[a-f0-9-]{36}$/',$in['restoreOf']))return new WP_Error('invalid','Invalid original operation',array('status'=>400));
   $original=get_option('aos_job_'.$in['restoreOf']);
   if(!$original||empty($original['metadataFields'])||!empty($original['restoreOf'])||isset($original['cleanup'])||($original['postId']??0)!==($s['postId']??-1)||($original['url']??'')!==$url||$metadataFields!==$original['metadataFields'])return new WP_Error('changed','The original metadata operation does not match this page and field scope',array('status'=>409));
   foreach($metadataFields as $f)if(($s[$f]??null)!==($original['expected'][$f]??null)||!array_key_exists($f,$original['before'])||$changes[0][$f]!==$original['before'][$f])return new WP_Error('changed','Restoration would overwrite newer wording or does not match the original values',array('status'=>409));
  }
 }
 if(($in['beforeHash']??'')!==$s['beforeHash'])return new WP_Error('changed','Website changed since preparation. Prepare again.',array('status'=>409));
 // 0.3.1 — expected state starts from the whole current state, so a change to
 // an existing page expects its author, comment setting and layout to stay
 // exactly as found. 0.3.0 began recording those three in the saved state
 // without expecting them, so every existing-page change verified false.
 $id=$s['postId']??0;$expected=array('content'=>$s['content'],'title'=>$s['title'],'description'=>$s['description'],'schema'=>$s['schema']??'','featured'=>(int)($s['featured']??0),'author'=>(int)($s['author']??0),'commentStatus'=>(string)($s['commentStatus']??''),'pingStatus'=>(string)($s['pingStatus']??''),'layout'=>(string)($s['layout']??''),'focusKeyword'=>(string)($s['focusKeyword']??''));$new=null;$seo=false;
 $changes=$in['changes']??array();if(!is_array($changes)||!count($changes)||count($changes)>10)return new WP_Error('invalid','No valid changes',array('status'=>400));
 foreach($changes as $c){$kind=$c['kind']??'';
  if($kind==='metadata'){
   // 0.4.0 — the SEO package is Rank Math's title, description and focus
   // keyword (its documented post meta). A new post saves them whether or not
   // Rank Math is active, and the receipt says whether it is; an existing
   // page's SEO is still only edited where Rank Math will show it.
   $seo=true;
   foreach(array('title','description','focusKeyword') as $f)if(isset($c[$f])){if(!is_string($c[$f])||(!$restore&&trim($c[$f])==='')||strlen($c[$f])>2000||strip_tags($c[$f])!==$c[$f])return new WP_Error('invalid','Invalid metadata',array('status'=>400));$expected[$f]=$f==='focusKeyword'?sanitize_text_field($c[$f]):$c[$f];}
  }elseif($kind==='new_post'){
   // 0.5.0 — the same checks /preflight ran, so a proposal that passed
   // preflight cannot be refused here for a reason preflight did not name.
   $failed=aos_first_failure(aos_new_post_checks($c,$id,$new));if($failed)return new WP_Error($failed['code'],$failed['message'],array('status'=>409));
   $new=$c;$new['html']=aos_normalized_html($c['html']);$expected['content']=$new['html'];
  }elseif($kind==='schema'){
   if(!is_array($c['value']??null)||($c['value']['@context']??'')!=='https://schema.org'||empty($c['value']['@type']))return new WP_Error('schema','Provide valid JSON-LD',array('status'=>400));$expected['schema']=$c['value'];
  }elseif(in_array($kind,array('replace_text','replace_html','append_html'),true)){
   if(!$id)return new WP_Error('missing','Read the existing page before editing it',array('status'=>409));
   if($kind==='append_html'){
    if(strpos($expected['content'],'[et_pb_')!==false||get_post_meta($id,'_et_pb_use_builder',true)==='on')return new WP_Error('divi','This Divi page requires an exact section replacement to preserve its layout',array('status'=>409));
    if(!aos_safe_html($c['html']??''))return new WP_Error('html','Content contains unsupported markup',array('status'=>400));$expected['content'].="\n".aos_normalized_html($c['html']);
   }else{
    $before=$c['before']??'';$after=$kind==='replace_text'?($c['after']??''):aos_normalized_html($c['html']??'');
    if(!is_string($before)||trim($before)===''||!is_string($after)||trim($after)===''||substr_count($expected['content'],$before)!==1)return new WP_Error('ambiguous','The exact section must occur once in this page',array('status'=>409));
    if($kind==='replace_text'&&preg_match('/[<>\[\]]/',$before.$after))return new WP_Error('markup','Text edits must preserve markup',array('status'=>409));
    if($kind==='replace_html'&&(!aos_safe_html($after)||strpos($before,'[et_pb_')!==false||strpos($after,'[et_pb_')!==false))return new WP_Error('markup','Use an exact content section without replacing Divi layout markup',array('status'=>409));
    $expected['content']=str_replace($before,$after,$expected['content']);
   }
  }else return new WP_Error('unsupported','Unsupported publishing action',array('status'=>409));
 }
 if(!$id&&!$new)return new WP_Error('missing','The target page does not exist',array('status'=>409));
 if($seo&&!$new&&!defined('RANK_MATH_VERSION'))return new WP_Error('rankmath','Activate Rank Math before applying SEO metadata',array('status'=>409));
 // 0.3.0 — how a new post publishes. An existing page keeps its author,
 // comment setting and layout exactly as they are.
 $pub=is_array($in['publishing']??null)?$in['publishing']:array();$layoutRequested='';$layoutMechanism=null;
 if($new){
  $expected['commentStatus']=(($pub['commentStatus']??'closed')==='open')?'open':'closed';
  $expected['pingStatus']=(($pub['pingStatus']??'open')==='closed')?'closed':'open';
  if(isset($pub['focusKeyword'])&&is_string($pub['focusKeyword'])&&trim($pub['focusKeyword'])!==''){if(strlen($pub['focusKeyword'])>200||strip_tags($pub['focusKeyword'])!==$pub['focusKeyword'])return new WP_Error('invalid','Invalid focus keyword',array('status'=>400));$expected['focusKeyword']=sanitize_text_field($pub['focusKeyword']);}
  $author=(int)($pub['authorId']??0);
  if($author){if(!get_userdata($author)||!user_can($author,'edit_posts'))return new WP_Error('author','Choose an author who can write posts on this site',array('status'=>409));if($author!==get_current_user_id()&&!current_user_can('edit_others_posts'))return new WP_Error('author','This connection cannot publish as another author',array('status'=>403));}
  else $author=get_current_user_id();
  $expected['author']=$author;
  $layoutRequested=(string)($pub['layout']??'');
  if($layoutRequested==='full_width'){$mech=aos_layout_mechanism();$layoutMechanism=$mech['mechanism'];$expected['layout']=$mech['mechanism']?$mech['value']:'';}
  else $expected['layout']='';
 }
 $media=$in['media']??array();if(!is_array($media)||count($media)>10)return new WP_Error('media','Too many images',array('status'=>400));if(count($media)&&!current_user_can('upload_files'))return new WP_Error('media','Image upload permission is required',array('status'=>403));foreach($media as $m){$bytes=base64_decode($m['base64']??'',true);$size=$bytes?getimagesizefromstring($bytes):false;if(!$bytes||strlen($bytes)>12000000||!$size||!in_array($size['mime'],array('image/png','image/jpeg','image/webp'),true)||$size['mime']!==($m['mimeType']??'')||hash('sha256',$bytes)!==($m['sha256']??''))return new WP_Error('media','An approved image is invalid or has changed',array('status'=>400));}
 $j=array('jobId'=>$in['jobId'],'proposalHash'=>$in['proposalHash'],'postId'=>$id,'url'=>$url,'before'=>$s,'expected'=>$expected,'layoutRequested'=>$layoutRequested,'layoutMechanism'=>$layoutMechanism);if($automatic){$j['metadataFields']=$metadataFields;if($restore)$j['restoreOf']=$in['restoreOf'];}if($new)$j['newTitle']=$new['title'];
 $lock='aos_lock_'.hash('sha256',$url);if(!add_option($lock,$in['jobId'],'',false))return new WP_Error('busy','Another approved change is being applied to this page',array('status'=>409));
 try{
  $fresh=aos_snapshot($url);if(is_wp_error($fresh)||$fresh['beforeHash']!==$s['beforeHash'])return new WP_Error('changed','Website changed during preparation',array('status'=>409));
  if(!add_option($key,$j,'',false))return new WP_Error('busy','This approval is already being processed',array('status'=>409));
  // 0.5.2.2 — every attachment, raw uploaded file, and newly created
  // category term this ATTEMPT creates is tracked here from the moment the
  // aos_job option exists, so $rollback can undo exactly what this attempt
  // did on any failure from this point on — including a media-upload or
  // attachment-creation failure that happens before a new post's draft is
  // even inserted. $createdPostId is only ever set once wp_insert_post
  // succeeds for a NEW post; an existing page being edited is never
  // assigned to it and is therefore never touched by rollback.
  $rawFiles=array();$createdTerms=array();$createdPostId=null;
  // 0.5.2.3 — the post may already be live when this runs (a failure
  // discovered only after the publish transition, e.g. final verification).
  // A failed attempt to force it back to non-public must never stop the
  // rollback from still attempting a hard delete — the old behavior gave up
  // right there, which could leave a public article behind with an error
  // message that falsely claimed it had been moved to draft. Both steps are
  // attempted unconditionally, and only the post's OWN, freshly re-read
  // status after both — never wp_update_post()'s or wp_delete_post()'s own
  // return value — decides what actually happened.
  $rollback=function($error)use($key,&$j,&$rawFiles,&$createdTerms,&$createdPostId){
   $postRetained=false;$postPublic=false;$finalStatus=false;
   if($createdPostId){
    if(get_post_status($createdPostId)==='publish')wp_update_post(wp_slash(array('ID'=>$createdPostId,'post_status'=>'draft')),true);
    wp_delete_post($createdPostId,true);
    $finalStatus=get_post_status($createdPostId);
    if($finalStatus!==false){$postRetained=true;$postPublic=($finalStatus==='publish');}
   }
   if($postRetained){
    // 0.5.2.3 — the post could not be fully removed. Its media and any
    // newly created category terms are still legitimately referenced by
    // it — whether it is a dangerously-retained PUBLIC article or a
    // recoverable non-public draft — so neither is deleted here; doing so
    // would damage a post this rollback failed to remove. The job option
    // is preserved (never delete_option), with the post's own verified
    // status recorded, so a retry for this exact job can never fall
    // through to a normal — and possibly misleadingly successful —
    // receipt; see aos_cleanup_status() and its use in aos_apply().
    $j['cleanup']=array('postId'=>$createdPostId,'postStatus'=>$finalStatus,'public'=>$postPublic);
    update_option($key,$j,false);
    if($postPublic)return new WP_Error('cleanup_required_critical','This article could not be safely removed after a publishing failure and may still be publicly visible. Immediate manual action is required: review and unpublish or delete post ID '.$createdPostId.' on this site.',array('status'=>500,'postId'=>$createdPostId));
    return new WP_Error('cleanup_required','This publishing attempt failed and the resulting draft could not be fully removed automatically. It has been verified non-public (post ID '.$createdPostId.'), but needs manual review before retrying this job.',array('status'=>409,'postId'=>$createdPostId));
   }
   // 0.5.2.2 — the post is confirmed gone (or never existed for this
   // attempt); every resource this attempt created is now genuinely
   // orphaned and safe to remove. A newly created category term is removed
   // only once it is confirmed still unused (WordPress decrements a term's
   // count as its last post is removed above, so a count of zero here
   // means nothing else references it).
   foreach(($j['media']??array()) as $m)wp_delete_attachment($m['attachmentId'],true);
   foreach($rawFiles as $f)wp_delete_file($f);
   foreach($createdTerms as $t){$term=get_term($t['id'],'category');if($term&&!is_wp_error($term)&&(int)($term->count??0)===0)wp_delete_term($t['id'],'category');}
   delete_option($key);
   return $error;
  };
  // 0.5.2.2 — a raw uploaded file is tracked in $rawFiles the instant it
  // exists on disk, before it becomes an attachment; popped back off once
  // wp_insert_attachment succeeds, since it is then owned by that
  // attachment's own cleanup instead.
  $j['media']=array();if(count($media)){foreach($media as $m){$ext=array('image/png'=>'png','image/jpeg'=>'jpg','image/webp'=>'webp')[$m['mimeType']];$name=sanitize_file_name((string)($m['fileName']??''));if($name===''||!preg_match('/\.(png|jpe?g|webp)$/i',$name))$name=sanitize_file_name($in['jobId'].'-'.$m['assetId'].'.'.$ext);$upload=wp_upload_bits($name,null,base64_decode($m['base64'],true));if($upload['error'])return $rollback(new WP_Error('media',$upload['error'],array('status'=>500)));$rawFiles[]=$upload['file'];$aid=wp_insert_attachment(array('post_mime_type'=>$m['mimeType'],'post_title'=>sanitize_text_field($m['alt']),'post_status'=>'inherit'),$upload['file']);if(is_wp_error($aid)||!$aid)return $rollback(new WP_Error('media','Could not save image',array('status'=>500)));array_pop($rawFiles);update_post_meta($aid,'_wp_attachment_image_alt',wp_slash($m['alt']));$expected['content']=str_replace('https://agency-os-image.invalid/'.$m['assetId'],esc_url(wp_get_attachment_url($aid)),$expected['content']);if($m['role']==='featured')$expected['featured']=(int)$aid;$j['media'][]=array('attachmentId'=>$aid,'sha256'=>$m['sha256'],'alt'=>$m['alt'],'role'=>(string)($m['role']??''));}$j['expected']=$expected;update_option($key,$j,false);}
  if($new){
   // 0.5.2.1 — fail closed. A new article used to go live (post_status
   // publish) before its categories were even resolved: if resolution,
   // creation or assignment then failed, the article was already public,
   // Uncategorized. It now starts as a draft — never publicly visible —
   // and is flipped to publish only once every required element of the
   // approved package (categories included) is applied and verified. Any
   // failure along the way rolls the whole attempt back through the
   // $rollback closure above and returns a specific WP_Error; nothing here
   // ever falls through to publish on an incomplete package.
   $insert=array('post_type'=>$new['postType'],'post_status'=>'draft','post_title'=>$new['title'],'post_name'=>$new['slug'],'post_content'=>$expected['content'],'post_author'=>$expected['author'],'comment_status'=>$expected['commentStatus'],'ping_status'=>$expected['pingStatus'],'meta_input'=>array('_aos_job'=>$in['jobId']));
   if($layoutMechanism==='template')$insert['page_template']=$expected['layout'];
   $id=wp_insert_post(wp_slash($insert),true);
   if(is_wp_error($id))return $rollback($id);
   $createdPostId=$id;
   if($layoutMechanism==='divi')update_post_meta($id,'_et_pb_page_layout',$expected['layout']);
   $j['postId']=$id;update_option($key,$j,false);
   // 0.5.2.1 — categories are resolved and assigned once the post exists. A
   // new category is created here, never at preflight, only when the
   // operator explicitly approved it; get_term_by('slug',...) makes a
   // retried apply idempotent — it finds the term a previous attempt
   // already created rather than making a duplicate. Every failure here —
   // creation, assignment, or the post-assignment readback — is a real
   // WP_Error with a specific message, never silently swallowed into null.
   if(aos_category_contract($new)){
    $catSel=$new['categories']??null;
    $resolveOrCreate=function($sel)use(&$createdTerms){
     if(!is_array($sel))return null;
     if(($sel['source']??'')==='existing'){$tid=(int)($sel['id']??0);return ($tid>0&&term_exists($tid,'category'))?$tid:null;}
     if(($sel['source']??'')==='new'&&!empty($sel['approved'])){
      if(!current_user_can('manage_categories'))return new WP_Error('category_permission','This WordPress user cannot create the approved category on this site.',array('status'=>403));
      $slug=sanitize_title((string)($sel['slug']??$sel['name']));
      $existing=get_term_by('slug',$slug,'category');
      if($existing&&!is_wp_error($existing))return (int)$existing->term_id;
      $result=wp_insert_term(wp_slash((string)$sel['name']),'category',array('slug'=>$slug));
      if(is_wp_error($result))return new WP_Error('category_create','The approved category could not be created: '.$result->get_error_message(),array('status'=>500));
      $createdTerms[]=array('id'=>(int)$result['term_id'],'slug'=>$slug);
      return (int)$result['term_id'];
     }
     return null;
    };
    $primaryId=$resolveOrCreate($catSel['primary']??null);
    if(is_wp_error($primaryId))return $rollback($primaryId);
    if(!$primaryId)return $rollback(new WP_Error('category_primary','The approved primary category could not be resolved on this site.',array('status'=>409)));
    $secondaryId=($catSel['secondary']??null)?$resolveOrCreate($catSel['secondary']):null;
    if(is_wp_error($secondaryId))return $rollback($secondaryId);
    $categoryIds=array_values(array_unique(array_filter(array($primaryId,$secondaryId))));
    $assigned=wp_set_post_categories($id,$categoryIds);
    if(is_wp_error($assigned))return $rollback(new WP_Error('category_assign','The approved categories could not be saved: '.$assigned->get_error_message(),array('status'=>500)));
    if(!is_array($assigned))return $rollback(new WP_Error('category_assign','WordPress returned an unexpected result assigning the approved categories.',array('status'=>500)));
    $confirmedIds=wp_get_post_categories($id);
    // 0.5.2.2 — the readback itself can fail (a WP_Error, or some other
    // non-array value) after assignment reported success. Never pass either
    // into in_array() below; a readback that cannot be trusted is treated
    // exactly like a readback that contradicts the approved selection.
    if(is_wp_error($confirmedIds)||!is_array($confirmedIds))return $rollback(new WP_Error('category_verify','The approved categories could not be confirmed after saving.',array('status'=>500)));
    if(!in_array($primaryId,$confirmedIds,true))return $rollback(new WP_Error('category_verify','The approved primary category was not confirmed assigned after saving.',array('status'=>500)));
    if($secondaryId&&!in_array($secondaryId,$confirmedIds,true))return $rollback(new WP_Error('category_verify','The approved additional category was not confirmed assigned after saving.',array('status'=>500)));
    if(defined('RANK_MATH_VERSION'))update_post_meta($id,'rank_math_primary_category',$primaryId);
    $j['categories']=array('primaryId'=>$primaryId,'secondaryId'=>$secondaryId,'created'=>array_map(function($t){return $t['slug'];},$createdTerms));
    update_option($key,$j,false);
   }
   if($expected['title']!==$s['title'])update_post_meta($id,'rank_math_title',wp_slash($expected['title']));
   if($expected['description']!==$s['description'])update_post_meta($id,'rank_math_description',wp_slash($expected['description']));
   if($expected['focusKeyword']!==($s['focusKeyword']??''))update_post_meta($id,'rank_math_focus_keyword',wp_slash($expected['focusKeyword']));
   if($expected['schema']!==($s['schema']??''))update_post_meta($id,'_aos_schema',wp_slash($expected['schema']));
   if($expected['featured']!==($s['featured']??0))set_post_thumbnail($id,$expected['featured']);
   foreach($j['media'] as $m)wp_update_post(array('ID'=>$m['attachmentId'],'post_parent'=>$id));
   clean_post_cache($id);
   // 0.5.2.1 — the post becomes publicly visible only now, and only once.
   $published=wp_update_post(wp_slash(array('ID'=>$id,'post_status'=>'publish')),true);
   if(is_wp_error($published))return $rollback($published);
   clean_post_cache($id);
   $receipt=aos_receipt($j);
   // 0.5.2.2 — aos_receipt() itself can return a WP_Error (for example if
   // access is re-checked and fails); guard before ever indexing
   // ['verified'] on it, since PHP 8 fatally errors indexing a non-array
   // object. Either way, a receipt that is not a confirmed-verified array
   // rolls the whole attempt back — the post may already be live at this
   // point, which is exactly what $rollback's force-to-draft-then-delete
   // sequence above exists to undo.
   if(is_wp_error($receipt)||!is_array($receipt)||!$receipt['verified'])return $rollback(is_wp_error($receipt)?$receipt:new WP_Error('unverified','The approved publication could not be verified after publishing.',array('status'=>500)));
   aos_schedule_attachment_metadata($j['media']);
   return $receipt;
  }
  elseif($expected['content']!==$s['content']){$result=wp_update_post(wp_slash(array('ID'=>$id,'post_content'=>$expected['content'])),true);if(is_wp_error($result))return $result;}
  if($expected['title']!==$s['title'])update_post_meta($id,'rank_math_title',wp_slash($expected['title']));if($expected['description']!==$s['description'])update_post_meta($id,'rank_math_description',wp_slash($expected['description']));if($expected['focusKeyword']!==($s['focusKeyword']??''))update_post_meta($id,'rank_math_focus_keyword',wp_slash($expected['focusKeyword']));if($expected['schema']!==($s['schema']??''))update_post_meta($id,'_aos_schema',wp_slash($expected['schema']));if($expected['featured']!==($s['featured']??0))set_post_thumbnail($id,$expected['featured']);foreach($j['media'] as $m)wp_update_post(array('ID'=>$m['attachmentId'],'post_parent'=>$id));clean_post_cache($id);$receipt=aos_receipt($j);if(is_array($receipt)&&!empty($receipt['verified']))aos_schedule_attachment_metadata($j['media']);return $receipt;
 }finally{delete_option($lock);}
}
add_action('rest_api_init',function(){
 $permission=function(){return current_user_can('edit_posts');};
 register_rest_route('agency-os/v1','/capabilities',array('methods'=>'GET','permission_callback'=>$permission,'callback'=>function(){$layout=aos_layout_mechanism();return array('protocol'=>AOS_PROTOCOL_VERSION,'version'=>AOS_PLUGIN_VERSION,'media'=>true,'preflight'=>true,'kinds'=>array('metadata','replace_text','replace_html','append_html','new_post','schema'),'metadataAutomation'=>array('version'=>1,'restore'=>true),'site'=>home_url(),'authors'=>true,'publishing'=>array('comments'=>true,'pings'=>true,'author'=>true,'layout'=>array('fullWidth'=>(bool)$layout['mechanism'],'mechanism'=>$layout['mechanism'],'label'=>$layout['label']),'seo'=>array('rankMath'=>defined('RANK_MATH_VERSION'),'title'=>true,'description'=>true,'focusKeyword'=>true)),'categories'=>array('discovery'=>true,'assignment'=>true,'creation'=>current_user_can('manage_categories'),'rankMathPrimary'=>defined('RANK_MATH_VERSION')));}));
 register_rest_route('agency-os/v1','/authors',array('methods'=>'GET','permission_callback'=>$permission,'callback'=>function(){return aos_authors();}));
 register_rest_route('agency-os/v1','/categories',array('methods'=>'GET','permission_callback'=>$permission,'callback'=>function(){return aos_categories();}));
 register_rest_route('agency-os/v1','/snapshot',array('methods'=>'POST','permission_callback'=>$permission,'callback'=>function($r){return aos_snapshot($r['url']);}));
 register_rest_route('agency-os/v1','/jobs/(?P<id>[a-f0-9-]+)',array('methods'=>'GET','permission_callback'=>$permission,'callback'=>function($r){$j=get_option('aos_job_'.$r['id']);if(!$j)return new WP_Error('unknown','No recorded operation; do not assume the change was applied',array('status'=>404));if(isset($j['cleanup']))return aos_cleanup_status($j);return aos_receipt($j);}));
 register_rest_route('agency-os/v1','/preflight',array('methods'=>'POST','permission_callback'=>$permission,'callback'=>'aos_preflight'));
 register_rest_route('agency-os/v1','/apply',array('methods'=>'POST','permission_callback'=>$permission,'callback'=>'aos_apply'));
});
add_action('wp_head',function(){if(is_singular()){$schema=get_post_meta(get_queried_object_id(),'_aos_schema',true);if(is_array($schema))echo '<script type="application/ld+json">'.wp_json_encode($schema,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT).'</script>';}});
// 0.5.4 — WordPress's own third-party plugin-update mechanism (the "Update
// URI" header above, matched to this filter's host). Publisher updates are
// explicitly opted into WordPress's background updater for this plugin only.
// WordPress still owns scheduling, permissions, maintenance mode, recovery
// and any global file-modification policy. The checksum gate below refuses a
// missing, corrupted or tampered package before installation.
function aos_fetch_manifest(){$cached=get_site_transient('aos_manifest_cache');if(is_array($cached))return $cached;$response=wp_remote_get(AOS_MANIFEST_URL,array('timeout'=>10));if(is_wp_error($response)||wp_remote_retrieve_response_code($response)!==200)return null;$m=json_decode(wp_remote_retrieve_body($response),true);if(!is_array($m)||empty($m['version'])||empty($m['zipUrl']))return null;set_site_transient('aos_manifest_cache',$m,HOUR_IN_SECONDS);return $m;}
// 0.5.6 — WordPress validates version before normalizing new_version.
// Supply both so native update discovery accepts this response.
add_filter('update_plugins_github.com',function($update,$plugin_data,$plugin_file){
 if(plugin_basename(__FILE__)!==$plugin_file)return $update;
 $m=aos_fetch_manifest();if(!$m||version_compare((string)$m['version'],AOS_PLUGIN_VERSION,'<='))return $update;
 return array('id'=>AOS_MANIFEST_URL,'slug'=>'agency-os-publisher','plugin'=>$plugin_file,'version'=>(string)$m['version'],'new_version'=>(string)$m['version'],'url'=>(string)($m['detailsUrl']??''),'package'=>(string)$m['zipUrl'],'requires'=>(string)($m['requiresWordPress']??''),'requires_php'=>(string)($m['requiresPhp']??''),'tested'=>(string)($m['testedWordPress']??''),'autoupdate'=>true);
},10,3);
function aos_is_own_update_item($item){
 if(!is_object($item))return false;
 $plugin=(string)($item->plugin??'');$slug=(string)($item->slug??'');$id=(string)($item->id??'');
 return $plugin===plugin_basename(__FILE__)||$slug==='agency-os-publisher'||$id===AOS_MANIFEST_URL;
}
add_filter('auto_update_plugin',function($update,$item){return aos_is_own_update_item($item)?true:$update;},10,2);
// 0.5.0.1 — the manifest's SHA-256 verified before WordPress installs this
// plugin's own update, fail-closed. upgrader_pre_download lets a plugin
// perform (and vouch for) its own package download; returning the verified
// local file path here is WordPress's documented way to do that, so this is
// still WordPress's native updater, not a replacement for it. Scoped to this
// plugin's own package only — every other plugin and core update returns
// $reply=false unchanged and downloads exactly as WordPress always has.
add_filter('upgrader_pre_download',function($reply,$package,$upgrader,$hook_extra=array()){
 $plugin=is_array($hook_extra)?($hook_extra['plugin']??''):'';
 if($plugin!==plugin_basename(__FILE__))return $reply;
 $m=aos_fetch_manifest();
 if(!$m||empty($m['sha256'])||!preg_match('/^[a-f0-9]{64}$/i',(string)$m['sha256']))return new WP_Error('aos_checksum_missing','Agency OS Publisher update refused: no checksum was published for this release, so it cannot be verified.');
 $file=download_url($package,300);
 if(is_wp_error($file))return $file;
 $actual=hash_file('sha256',$file);
 if(!$actual||!hash_equals(strtolower((string)$m['sha256']),strtolower($actual))){@unlink($file);return new WP_Error('aos_checksum_mismatch','Agency OS Publisher update refused: the downloaded package does not match its published checksum. This may be a corrupted download or a tampered release; it was not installed.');}
 return $file;
},10,4);
add_filter('plugins_api',function($result,$action,$args){
 if($action!=='plugin_information'||($args->slug??'')!=='agency-os-publisher')return $result;
 $m=aos_fetch_manifest();if(!$m)return $result;
 return (object)array('name'=>'Agency OS Approved Publisher','slug'=>'agency-os-publisher','version'=>(string)($m['version']??AOS_PLUGIN_VERSION),'download_link'=>(string)($m['zipUrl']??''),'requires'=>(string)($m['requiresWordPress']??''),'requires_php'=>(string)($m['requiresPhp']??''),'tested'=>(string)($m['testedWordPress']??''),'sections'=>array('description'=>(string)($m['notes']??'Applies explicitly approved website changes and verifies their saved values.')));
},10,3);
